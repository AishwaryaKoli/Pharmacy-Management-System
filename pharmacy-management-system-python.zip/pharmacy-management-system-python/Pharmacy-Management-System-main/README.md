# Pharmacy-Management-System
This project how to create pharmacy management system using Tkinter in python with MYSQL
